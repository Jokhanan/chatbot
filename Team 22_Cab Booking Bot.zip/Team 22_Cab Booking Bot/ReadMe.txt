Team selected Domain: Cab booking from Hyderabad airport
Common domain: Restaurant Search

Bonus tasks attempted:
1. Spelling mistakes handling. Valid spelling non-present in database will not be handled.

2. Graceful restart at any stage of the chat
	> Exit at any point during conversation, using "Exit" keyword
	> Continuing to new task(Cab booking or Restaurant search after the first task is complete)
